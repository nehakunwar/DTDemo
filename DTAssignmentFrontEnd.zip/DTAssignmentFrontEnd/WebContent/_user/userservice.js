app.factory('UserService',function($http){
	var userService=this;
	var BASE_URL="http://localhost:8089/DTBackend/"
	userService.authenticate=function(user){
		return $http.post(BASE_URL + "/authenticate",user);
	}
	
	userService.registerUser=function(user){
		return $http.post(BASE_URL + "/user",user) 
	}
	
	return userService;
})